package com.example.data.repository;

import com.example.data.model.Blog;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class BlogRepository implements IBlogRepository{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Blog> findAll() {
        String query =  "select b from Blog b";
        TypedQuery<Blog> typedQuery =
                entityManager.createQuery(query,Blog.class);

        return typedQuery.getResultList();
    }

    @Override
    @Modifying
    @Transactional
    public void remove(Integer id) {
        entityManager.remove(findById(id));
    }

    @Override
    public Blog findById(int id) {
        return entityManager.find(Blog.class,id);
    }

    @Override
    @Transactional
    @Modifying
    public void save(Blog blog) {
        if (blog.getId() == null){
            entityManager.persist(blog);
        } else {
            entityManager.merge(blog);
        }
    }
}
