package com.example.data.service;

import com.example.data.model.Blog;

import java.util.List;

public interface IBlogService {


    List<Blog> findAll();

    void remove(Integer id);

    Blog findById(int id);

    void save(Blog blog);
}
