package com.example.data.repository;

import com.example.data.model.Blog;

import java.util.List;

public interface IBlogRepository {
    List<Blog> findAll();

    void remove(Integer id);

    Blog findById(int id);

    void save(Blog blog);
}
