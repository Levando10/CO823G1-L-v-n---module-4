SpringData

- Kỹ thuật ORM - Object Relational Mapping: là 1 kỹ thuật giúp mapping dữ liệu của object với các bảng được tạo trong Database
- Thiết kế CSDL => tạo CSDL => viết model => kết nối và truy vấn CSDL thông qua JDBC
- 1 số Framework đặc trung triển khai ORM:
  - Hibernate
  - JPA
- HQL - Hibernate Query Language: ngôn ngữ truy vấn của Hibernate, hỗ trợ truy vấn dữ liệu từ CSDL thông qua các Model tạo nên CSDL đó
- resource: chứa các tài nguyên tĩnh của dự án Spring
